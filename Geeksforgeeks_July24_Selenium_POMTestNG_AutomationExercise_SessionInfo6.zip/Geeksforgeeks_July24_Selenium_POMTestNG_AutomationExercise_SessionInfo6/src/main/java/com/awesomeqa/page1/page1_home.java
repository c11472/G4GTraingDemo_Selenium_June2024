package com.awesomeqa.page1;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class page1_home {
	WebDriver wd;
	Properties or = new Properties(); // Locators
	
	Properties dt = new Properties(); // test data
	FileReader orF1,dtF2;

	
	public void init(WebDriver wd) {
		this.wd=wd;
		
	}
	
	public void Launch_Awsesome_qa() throws IOException {
		orF1 = new FileReader("./ObjectRepos_Awesomeqa/locatorsinfo.properties");
		dtF2 = new FileReader("./Testdata/testdatainput.properties");

		or.load(orF1);
		
		wd.get(or.getProperty("baseurl"));	
		
	}
	
	public void Enter_FirstName() throws IOException {
		
	//	dtF2 = new FileReader("./Testdata/testdatainput.properties");
		
		dt.load(dtF2);
		
	     wd.findElement(By.xpath(or.getProperty("firstnamelc"))).sendKeys(dt.getProperty("firstname1"));	
				
	}
	
	
	public void Launch_Google() throws IOException {
		
		orF1 = new FileReader("./ObjectRepos_Awesomeqa/locatorsinfo.properties");
		dtF2 = new FileReader("./Testdata/testdatainput.properties");
		or.load(orF1);
		dt.load(dtF2);
		
		wd.get(or.getProperty("b1"));
		wd.findElement(By.name(or.getProperty("inputstr"))).sendKeys(dt.getProperty("searchstr"));
			
	}
	public String Validate_Google_Title() {
		String actTitle=wd.getTitle(); //Google
		return actTitle; // PageTitle-Google
		
	}
	
	
}
