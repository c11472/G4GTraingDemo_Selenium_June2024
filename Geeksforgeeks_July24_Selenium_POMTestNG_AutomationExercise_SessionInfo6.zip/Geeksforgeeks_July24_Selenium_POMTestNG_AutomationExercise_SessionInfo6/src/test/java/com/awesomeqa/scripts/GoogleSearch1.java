package com.awesomeqa.scripts;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

import com.awesomeqa.page1.page1_home;

public class GoogleSearch1 {
  WebDriver wd = new FirefoxDriver();
  
  page1_home p1 = new page1_home();
  
  
  
  @Test
  public void function_googlesearchinput() throws IOException {
	  
	  p1.init(wd);
	  p1.Launch_Google();
	  
  }
}
