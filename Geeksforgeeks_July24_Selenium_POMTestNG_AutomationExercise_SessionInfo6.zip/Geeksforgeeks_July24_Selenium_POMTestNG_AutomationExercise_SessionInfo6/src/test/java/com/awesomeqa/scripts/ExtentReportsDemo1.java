package com.awesomeqa.scripts;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class ExtentReportsDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ExtentReports ext1; // class 
		ExtentTest test;//interface 

		ExtentHtmlReporter testreport = new ExtentHtmlReporter("./Reports/ExecutionReport1.html");
		ext1=new ExtentReports();
		ext1.attachReporter(testreport);
		test = ext1.createTest("user.dir", "test");

		//Update the data using test
		
		test.log(Status.INFO, "This is a sample info");
		test.log(Status.FAIL, "This step is faile due to element visibility problem");
		test.log(Status.WARNING, "Sample Warning");
		
	//	ext1.flush();
		ext1.close();

	}

}
