package com.awesomeqa.scripts;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

import com.awesomeqa.page1.page1_home;

public class Script001 {
  WebDriver wd = new FirefoxDriver();
  //Page objects
  
  page1_home o1 = new page1_home();
  @Test
  public void Launch_Method() throws IOException {
	  o1.init(wd);
	  o1.Launch_Awsesome_qa();
	  o1.Enter_FirstName();
  }
}
