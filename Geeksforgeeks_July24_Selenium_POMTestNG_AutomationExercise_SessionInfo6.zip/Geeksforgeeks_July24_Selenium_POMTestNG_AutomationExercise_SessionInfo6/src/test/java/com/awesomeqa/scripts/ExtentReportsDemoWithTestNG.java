package com.awesomeqa.scripts;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.opentelemetry.exporter.logging.SystemOutLogRecordExporter;

public class ExtentReportsDemoWithTestNG {
	ExtentReports ext1; // class 
	ExtentTest test;//interface 
	
	
  @BeforeTest
  public void setup() {
	 // ExtentReports ext1; // class 
		//ExtentTest test;//interface 

		ExtentHtmlReporter testreport = new ExtentHtmlReporter("./Reports/ExecutionReporttestng1.html");
		ext1=new ExtentReports();
		ext1.attachReporter(testreport);
		test = ext1.createTest("user.dir", "test"); 
  }

		//Update the data using test
@Test(priority=1)
public void step1() {
	    System.out.println("Step-1");
		test.log(Status.INFO, "This is a sample info");
}

@Test(priority=2)
public void step2() {
	    System.out.println("Failed step");
		test.log(Status.FAIL, "This step is faile due to element visibility problem");
		
}

@Test(priority=3)
        public void Sysout() {
			// TODO Auto-generated method stub
	      System.out.print("This is a warning");
		  test.log(Status.WARNING, "Sample Warning");


		}
@AfterTest

     
        public void teardown() { 
	     System.out.println("Post condition");
		ext1.close();
}

  }

