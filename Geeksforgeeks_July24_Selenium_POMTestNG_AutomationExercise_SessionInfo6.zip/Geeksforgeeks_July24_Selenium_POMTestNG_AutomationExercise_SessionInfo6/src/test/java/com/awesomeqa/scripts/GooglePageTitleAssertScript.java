package com.awesomeqa.scripts;

import static org.testng.Assert.assertEquals;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.awesomeqa.page1.page1_home;

public class GooglePageTitleAssertScript {
  WebDriver wd = new FirefoxDriver();
	  
  page1_home p1 = new page1_home();
  
  Properties P = new Properties();
  FileReader data;
	 
  @Test
  public void f() throws IOException {
	  data = new FileReader("./Testdata/testdatainput.properties");
	  p1.init(wd);
	  p1.Launch_Google();
	 String act1= p1.Validate_Google_Title(); // Call the return type method and strore the resule in string
	 P.load(data);
	 String expdata = P.getProperty("ExpTitle"); //google
	 Assert.assertEquals(act1, expdata); // Assert Failed
	 System.out.println(expdata + "  " + act1);
	 
       }
}
