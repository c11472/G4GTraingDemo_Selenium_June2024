package package1;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Testcase_script0 {
  @BeforeClass
  public void test1() {
	  System.out.println("For this class - TestCase_Script0");
	  
  }
  @Test
  public void f() {
	  System.out.println("Execute this class");
  }
  @AfterClass
  public void test2() {
	  System.out.println("End of the class...");
	  
  }

}
