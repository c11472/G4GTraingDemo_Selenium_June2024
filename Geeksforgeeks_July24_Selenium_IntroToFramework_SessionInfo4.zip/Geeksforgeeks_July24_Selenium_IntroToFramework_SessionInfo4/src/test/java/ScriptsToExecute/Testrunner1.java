package ScriptsToExecute;

import Library_Data.Lib1;
import Library_Data.Lib2;
import Library_Data.Lib3;

public class Testrunner1 {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		
		//Objects for library
		Lib1 l1 = new Lib1();
		
		
		//l2.function1();
		//l3.samplemethod();
		
		l1.StringConcat();
		
		

	}

}
