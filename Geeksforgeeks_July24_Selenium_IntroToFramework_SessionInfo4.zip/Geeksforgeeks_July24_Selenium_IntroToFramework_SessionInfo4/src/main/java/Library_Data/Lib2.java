package Library_Data;

public class Lib2 {
	
	public void function1() {
		System.out.println("Exception details !");
	}
	
	public void function2() {
		int num=100;
		int i;
		
		if(num<=103) {
			System.out.println("Valid data");
			
		}
		 
	}

}
