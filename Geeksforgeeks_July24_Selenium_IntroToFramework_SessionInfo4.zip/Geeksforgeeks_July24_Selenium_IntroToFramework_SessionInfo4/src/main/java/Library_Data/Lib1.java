package Library_Data;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class Lib1 {
	//Set of methods
	
	Properties P;
	FileReader F;
	//Locators
	
	public void precondition() {
		System.out.println("The step for pres condition");
	}
	
	public void postcondition() {
		System.out.println("Tear down steps");
	}
	
	public void StringConcat() throws Exception {
		
		//should not use static data directly in method
		F=new FileReader("./sampledata/testdatatest.properties");
		P=new Properties();
		P.load(F);
		String s1=P.getProperty("str1");//static data
		String s2 = P.getProperty("str2");
		String main1=s1.concat(s2);
		System.out.println(main1);
	}
	
	public void Fun_clear() {
		//new button clear automation
	}

}
