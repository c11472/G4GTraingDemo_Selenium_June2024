package Geeksforgeeks_July24_Selenium_TestNG_SessionInfo3.Geeksforgeeks_July24_Selenium_TestNG_SessionInfo3;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class SelectDemoTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriver wd = new FirefoxDriver();
		wd.get("https://katalon-demo-cura.herokuapp.com");
		
		WebElement el = wd.findElement(By.xpath("//*[@id=\"btn-make-appointment\"]"));
		//WebElement unm = wd.findElement(By.xpath("//*[@id=\"txt-username\"]"));
		el.click();

		WebElement unm= wd.findElement(By.xpath("//*[@id=\"txt-username\"]"));
		WebElement pwd = wd.findElement(By.xpath("//*[@id=\"txt-password\"]"));
		WebElement lgin = wd.findElement(By.xpath("//*[@id=\"btn-login\"]"));
		
		
		
		unm.sendKeys("John Doe");
		
		pwd.sendKeys("ThisIsNotAPassword");
		
		lgin.click();
		
		
		// Automate drop down
		
		
	     Select sel = (Select) wd.findElement(By.id("combo_facility"));
		// Fetch all the options
	     
	     
	     List<WebElement> opt=  sel.getOptions();
		 
		 for(int i=0;i<=opt.size()-1;i++) {
			 System.out.println(opt.get(i).getText());
		 } 
	   
	   
	     
		
		
		
		
		
		
		
		

	}

}
