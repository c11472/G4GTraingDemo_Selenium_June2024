package Geeksforgeeks_July24_Selenium_TestNG_SessionInfo3.Geeksforgeeks_July24_Selenium_TestNG_SessionInfo3;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class FindElementsDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriver wd = new FirefoxDriver();
		
		wd.get("https://www.awesomeqa.com/ui");
		
	List	<WebElement> el = (List<WebElement>) wd.findElements(By.tagName("a"));
		System.out.println(el.size());
		for(int i=0;i<=el.size()-1;i++) {
			String values = el.get(i).getText();
			System.out.println(values);
		}

	}

}
