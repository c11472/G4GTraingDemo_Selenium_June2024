package Geeksforgeeks_July24_Selenium_TestNG_SessionInfo3.Geeksforgeeks_July24_Selenium_TestNG_SessionInfo3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class DargAndDropTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriver wd = new FirefoxDriver();
		
		wd.get("https://jqueryui.com/droppable/");
		// enter into frame
		
		wd.switchTo().frame(0); // access frame
		
		WebElement srcel = wd.findElement(By.xpath("//*[@id=\"draggable\"]"));
		WebElement dest1 = wd.findElement(By.xpath("//*[@id=\"droppable\"]"));
		

		String res = srcel.getText();
		System.out.println(res);
		
		String res1= dest1.getText();
		System.out.println(res1);
		
		
		//Actions
		
        Actions act = new Actions(wd);
        
        act.dragAndDrop(srcel, dest1).perform();
        
        wd.switchTo().parentFrame(); //To switch back to parent frame , the main window
        
        WebElement msg = wd.findElement(By.xpath("//h1[contains(text(),\"Droppable\")]"));
        System.out.println(msg.getText());
        
       // wd.switchTo().frame(0);
       // wd.switchTo().parentFrame();
	}

}
