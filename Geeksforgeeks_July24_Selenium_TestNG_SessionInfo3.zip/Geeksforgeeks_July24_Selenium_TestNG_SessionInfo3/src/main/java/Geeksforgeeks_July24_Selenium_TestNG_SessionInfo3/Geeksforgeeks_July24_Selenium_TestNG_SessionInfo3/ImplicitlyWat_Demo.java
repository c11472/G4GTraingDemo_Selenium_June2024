package Geeksforgeeks_July24_Selenium_TestNG_SessionInfo3.Geeksforgeeks_July24_Selenium_TestNG_SessionInfo3;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ImplicitlyWat_Demo {
	
	/*
	 * 1. Implicitwait will keep on looking the element till the specified time then show the Exception
	 * 
	 */

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub        WebDriver driver = new ChromeDriver();
		
		WebDriver driver = new ChromeDriver();
		
		


        driver.get("https://www.google.com");
       driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        
	//	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

	   driver.findElement(By.name("q")).click();// #Exception
        
        // Your test steps here

	}

}
