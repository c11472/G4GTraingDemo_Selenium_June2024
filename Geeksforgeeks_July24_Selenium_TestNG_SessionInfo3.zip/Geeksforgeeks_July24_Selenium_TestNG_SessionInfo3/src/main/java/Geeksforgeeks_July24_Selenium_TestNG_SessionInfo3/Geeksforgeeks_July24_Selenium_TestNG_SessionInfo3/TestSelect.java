package Geeksforgeeks_July24_Selenium_TestNG_SessionInfo3.Geeksforgeeks_July24_Selenium_TestNG_SessionInfo3;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class TestSelect {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		WebDriver wd = new FirefoxDriver();
		wd.get("https://katalon-demo-cura.herokuapp.com");
		
		String strval1= "Appointment Confirmation";
		
		WebElement el = wd.findElement(By.xpath("//*[@id=\"btn-make-appointment\"]"));
		//WebElement unm = wd.findElement(By.xpath("//*[@id=\"txt-username\"]"));
		el.click();

		WebElement unm= wd.findElement(By.xpath("//*[@id=\"txt-username\"]"));
		WebElement pwd = wd.findElement(By.xpath("//*[@id=\"txt-password\"]"));
		WebElement lgin = wd.findElement(By.xpath("//*[@id=\"btn-login\"]"));
		
		
		unm.sendKeys("John Doe");
		
		pwd.sendKeys("ThisIsNotAPassword");
		
		lgin.click();
		
		
		// Automate drop down
		
		
	     Select sel = new Select(wd.findElement(By.id("combo_facility")));
	     // Select Option
	   // sel.selectByIndex(2);
	    //Visible Text
	     sel.selectByVisibleText("Seoul CURA Healthcare Center");
	    
	    
	    
	    //Values
	    
	    Thread.sleep(2000);
	    
	    List <WebElement> lst = sel.getOptions();
	    int sz = lst.size();
	    System.out.println(sz);
	    
	    for(int i=0;i<=lst.size()-1;i++) {
	    	System.out.println(lst.get(i).getText());
	    }
	    
	    
	    
	    // Calendar auto
	    
	   
        WebElement calendardetails = wd.findElement(By.xpath("//input[@id=\"txt_visit_date\"]"));
        calendardetails.click();
        
        WebElement right = wd.findElement(By.xpath("/html/body/div/div[1]/table/thead/tr[2]/th[3]"));
        right.click();
        WebElement date1 = wd.findElement(By.xpath("/html/body/div/div[1]/table/tbody/tr[3]/td[6]"));
        
        
        date1.click();
        
        WebElement inputmessage = wd.findElement(By.xpath("//textarea[@id=\"txt_comment\"]"));
        
        inputmessage.sendKeys("This is a demo appointment");
        
        WebElement submit = wd.findElement(By.xpath("//button[@id=\"btn-book-appointment\"]"));
        
        submit.click();
        
        
        String actmsg = wd.findElement(By.xpath("//*[contains(text(),\"Appointment Confirmation\")]")).getText();
        System.out.println(actmsg); //equals or TestNG assert
	}

}
