package Geeksforgeeks_July24_Selenium_TestNG_SessionInfo3.Geeksforgeeks_July24_Selenium_TestNG_SessionInfo3;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Hello world!
 *
 */
public class OrangeTravel_WebDriverWait 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        WebDriver obj = new ChromeDriver();
        
        obj.get("https://www.orangetravels.in/#/");
        
        WebDriverWait wait = new WebDriverWait(obj,Duration.ofSeconds(10)); 
        
       
        
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//button[@type=\"button\"])[1]")));
        obj.findElement(By.xpath("(//button[@type=\"button\"])[1]")).click();
        
        
        
        
        
    }
}
