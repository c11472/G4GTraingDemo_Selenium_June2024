package Geeksforgeeks_July24_Selenium_TestNG_SessionInfo3.Geeksforgeeks_July24_Selenium_TestNG_SessionInfo3;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class AlertDemo {

	public static void main(String[] args) {
		
		WebDriver wd = new FirefoxDriver();
		
		wd.get("https://mail.rediff.com/cgi-bin/login.cgi");
		
		wd.findElement(By.id("login1")).sendKeys("testsytem");
		
		wd.findElement(By.name("proceed")).click();
		
		// Access alert
		
		Alert act = wd.switchTo().alert();
		
		String message=act.getText();
		System.out.println(message);
		
		
		act.accept();
		
		wd.findElement(By.id("password")).sendKeys("tey7t8y");
		
	    

	}

}
